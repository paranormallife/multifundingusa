<?php
/**
 * Functions
 *
 * @file            functions.php
 * @package         MultiFunding USA
 * @modified        2019-09-13
 */

if (!class_exists('MultiFundingUSA2018')) :

class MultiFundingUSA2018 {

/**
 * Version
 *
 * @var String
 */
    protected $_version = '1.17';

/**
 * Google Fonts link
 *
 * @var String
 */
    protected $_googleFonts = 'https://fonts.googleapis.com/css?family=Montserrat:500,400,300,700|Roboto:400,700';

/**
 * Add actions, filters and shortcodes
 *
 * @return void
 */
    public function __construct() {
        // Set Google Fonts
        $this->_googleFonts = str_replace('|', '%7C', str_replace(',', '%2C', $this->_googleFonts));

        // Add actions
        add_action('after_setup_theme', array($this, 'setupTheme'));
        add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
        add_action('login_head', array($this, 'loginStyles'));

        // Login Header URL
        add_filter('login_headerurl', array($this, 'loginHeaderUrl'));

        // Login Header Title
        add_filter('login_headertitle', array($this, 'loginHeadertitle'));

        // Excerpt Length
        add_filter('excerpt_length', array($this, 'excerptLength'));

        // Shortcode Bracket for the_content
        add_filter('the_content', array($this, 'shortcodeBracketFilter'));

        // Edit Post/Page/Taxonomy Columns
        add_filter('manage_edit-post_columns', array($this, 'editPostColumns'));
        add_filter('manage_edit-page_columns', array($this, 'editPostColumns'));
        add_filter('manage_edit-category_columns', array($this, 'editPostColumns'));
        add_filter('manage_edit-post_tag_columns', array($this, 'editPostColumns'));

        add_action('manage_pages_custom_column', array($this, 'customColumns'));
        add_action('manage_posts_custom_column', array($this, 'customColumns'));

        // Remove Protected Title
        add_filter('protected_title_format', array($this, 'removeProtectedTitle'));

        // Format TinyMCE
        add_filter('tiny_mce_before_init', array($this, 'formatTinymce'));
        add_filter('acf/input/admin_footer', array($this, 'formatTinymceFooterACF'));

        // Remove unnecessary actions
        remove_action('wp_head', 'feed_links_extra');
        remove_action('wp_head', 'rsd_link');
        remove_action('wp_head', 'wlwmanifest_link');
        remove_action('wp_head', 'index_rel_link');
        remove_action('wp_head', 'parent_post_rel_link');
        remove_action('wp_head', 'start_post_rel_link');
        remove_action('wp_head', 'adjacent_posts_rel_link');
        remove_action('wp_head', 'locale_stylesheet');
        remove_action('wp_head', 'noindex');
        remove_action('wp_head', 'wp_print_styles');
        remove_action('wp_head', 'wp_print_head_scripts');
        remove_action('wp_head', 'wp_generator');

        // Remove emoticons
        remove_action('admin_print_styles', 'print_emoji_styles');
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('admin_print_scripts', 'print_emoji_detection_script');
        remove_action('wp_print_styles', 'print_emoji_styles');
        remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
        remove_filter('the_content_feed', 'wp_staticize_emoji');
        remove_filter('comment_text_rss', 'wp_staticize_emoji');
        //add_filter('tiny_mce_plugins', 'disable_emojicons_tinymce');

        // Add shortcodes
        add_shortcode('row', array($this, 'row_shortcode'));
        add_shortcode('column', array($this, 'column_shortcode'));
        add_shortcode('embed_content', array($this, 'embed_content_shortcode'));

        add_shortcode('checkbox_block', array($this, 'checkbox_block_shortcode'));
    }

/**
 * Setup Theme
 *
 * @return void
 */
    public function setupTheme() {
        add_editor_style($this->_googleFonts);
        add_editor_style('assets/stylesheets/editor.css');

        add_theme_support('post-thumbnails', array('page'));

        register_nav_menus(array(
            'main' => __('Main Navigation'),
        ));

        $this->acfSetup();

        //flush_rewrite_rules(false);
    }

/**
 * Enqueue Scripts
 *
 * @return void
 */
    public function enqueueScripts() {
        // Styles
        wp_enqueue_style('google-font', $this->_googleFonts, array(), '1.0', 'all');
        wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/vendors/font-awesome/css/font-awesome.min.css', array(), '4.7.0', 'all');

        wp_enqueue_style('screen', get_template_directory_uri() . '/assets/stylesheets/screen.css', array(), $this->_version, 'screen');
        wp_enqueue_style('print', get_template_directory_uri() . '/assets/stylesheets/print.css', array(), $this->_version, 'print');

        // Scripts
        wp_enqueue_script('selectivizr', get_template_directory_uri() . '/assets/javascript/selectivizr-min.js', array(), '1.0.2', false);
        wp_script_add_data('selectivizr', 'conditional', 'lt IE 9');

        wp_enqueue_script('modernizr', get_template_directory_uri() . '/assets/javascript/modernizr.min.js', array(), '2.7.1', false);

        wp_enqueue_script('main', get_template_directory_uri() . '/assets/javascript/main.js', array('jquery'), $this->_version, false);
    }

/**
 * Add Login CSS
 *
 * @return string HTML to output
 */
    public function loginStyles() {
        echo sprintf(
            '<link rel="stylesheet" type="text/css" media="all" href="%1$s/assets/stylesheets/login.css" />',
            get_bloginfo('template_url')
        );
    }

/**
 * Set Login Header URL
 *
 * @return string URL to set header link on login page
 */
    public function loginHeaderUrl($url = null) {
        return home_url();
    }

/**
 * Set Login title to Blog title
 *
 * @return string Login title
 */
    public function loginHeadertitle() {
        return get_bloginfo('name');
    }

/**
 * Set Excerpt Length
 *
 * @return integer Excerpt length in characters
 */
    public function excerptLength($length = 0) {
        return 55;
    }

/**
 * Fix shortcode construction
 *
 * @return string Fixed content
 */
    public function shortcodeBracketFilter($content) {
        $array = array (
            '<p>[' => '[',
            ']</p>' => ']',
            ']<br />' => ']',
        );
        return strtr($content, $array);
    }

/**
 * Edit Post Columns
 *
 * @return array $columns
 */
    public function editPostColumns($columns) {

        // remove the Yoast SEO columns
        unset($columns['wpseo-score']);
        unset($columns['wpseo-title']);
        unset($columns['wpseo-metadesc']);
        unset($columns['wpseo-focuskw']);
        unset($columns['wpseo-score-readability']);
        unset($columns['wpseo_score']);
        unset($columns['wpseo_score_readability']);

        return $columns;
    }

/**
 * Admin Columns: Custom
 *
 * @return string Output
 */
    public function customColumns($column) {
        global $post;

        switch ($column) {

        }
    }

/**
 * Remove Protected Title
 *
 * @return string
 */
    public function removeProtectedTitle($title = null) {
       return '%s';
    }

/**
 * Create custom TinyMCE settings
 *
 * @return array Settings
 */
    public function formatTinymce($in = array()) {
        $in['remove_linebreaks'] = false;
        $in['gecko_spellcheck'] = false;
        $in['keep_styles'] = true;
        $in['body_class'] = 'styles';
        $in['accessibility_focus'] = true;
        $in['tabfocus_elements'] = 'major-publishing-actions';
        $in['media_strict'] = false;
        $in['paste_remove_styles'] = false;
        $in['paste_remove_spans'] = false;
        $in['paste_strip_class_attributes'] = 'none';
        $in['paste_text_use_dialog'] = true;
        $in['wpeditimage_disable_captions'] = true;
        $in['plugins'] = 'tabfocus,paste,media,fullscreen,hr,wordpress,wpeditimage,wpgallery,wplink,wpdialogs,lists';
        $in['wpautop'] = true;
        $in['apply_source_formatting'] = false;
        $in['toolbar1'] = 'bold,italic,underline,strikethrough,bullist,numlist,outdent,indent,hr,alignleft,aligncenter,alignright,alignjustify';
        $in['toolbar2'] = 'styleselect,link,unlink,pastetext,removeformat,wp_more,undo,redo,wp_help';
        $in['toolbar3'] = null;
        $in['toolbar4'] = null;
        $in['wordpress_adv_hidden'] = false;
        $in['style_formats'] = json_encode(array(
            array(
                'title' => 'Headers',
                'items' => array(
                    array(
                        'title' => 'Paragraph',
                        'block' => 'p',
                    ),
                    array(
                        'title' => 'Header 1',
                        'block' => 'h1',
                    ),
                    array(
                        'title' => 'Header 2',
                        'block' => 'h2',
                    ),
                    array(
                        'title' => 'Header 3',
                        'block' => 'h3',
                    ),
                    array(
                        'title' => 'Header 4',
                        'block' => 'h4',
                    ),
                    array(
                        'title' => 'Header 5',
                        'block' => 'h5',
                    ),
                    array(
                        'title' => 'Header 6',
                        'block' => 'h6',
                    ),
                    array(
                        'title' => 'Blockquote',
                        'block' => 'blockquote',
                        'wrapper' => true,
                    ),
                ),
            ),
            array(
                'title' => 'Margins',
                'items' => array(
                    array(
                        'title' => 'Margin - None',
                        'classes' => 'margin-none',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Margin - Small',
                        'classes' => 'margin-sm',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Margin - Medium',
                        'classes' => 'margin-md',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Margin - Large',
                        'classes' => 'margin-lg',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Margin - Extra Large',
                        'classes' => 'margin-xl',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                ),
            ),
            array(
                'title' => 'Text Colors',
                'items' => array(
                    array(
                        'title' => 'Black',
                        'classes' => 'textColor-black',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Gray',
                        'classes' => 'textColor-gray',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                    array(
                        'title' => 'Green',
                        'classes' => 'textColor-green',
                        'selector' => '*',
                        'inline' => 'span',
                    ),
                ),
            ),
            array(
                'title' => 'Buttons',
                'items' => array(
                    array(
                        'title' => 'Regular Button',
                        'selector' => 'a,button',
                        'classes' => 'button',
                    ),
                    array(
                        'title' => 'Large Button',
                        'selector' => 'a,button',
                        'classes' => 'button lg',
                    ),
                    array(
                        'title' => 'Full Width Button',
                        'selector' => 'a,button',
                        'classes' => 'button full',
                    ),
                ),
            ),
        ));

        return $in;
    }

/**
 * Row Shortcode Function
 *
 * @return string Output from shortcode
 */
    public function row_shortcode($atts, $content = null) {
        extract(shortcode_atts(array(
            'break' => 'lg',
            'class' => null,
        ), $atts));
        return sprintf('<div class="row break-%s %s">%s</div>',
            esc_attr($break),
            esc_attr($class),
            apply_filters('the_content', $content)
        );
    }

/**
 * Column Shortcode Function
 *
 * @return string Output from shortcode
 */
    public function column_shortcode($atts, $content = null) {
        extract(shortcode_atts(array(
            'width' => 'twelve',
            'valign' => 'top',
            'halign' => 'left',
            'class' => null,
        ), $atts));
        return sprintf('<div class="column %s valign-%s halign-%s %s">%s</div>',
            esc_attr($width),
            esc_attr($valign),
            esc_attr($halign),
            esc_attr($class),
            apply_filters('the_content', $content)
        );
    }

/**
 * Embed Content Shortcode Function
 *
 * @return string Output from shortcode
 */
    public function embed_content_shortcode($atts, $content = null) {
        extract(shortcode_atts(array(
            'link' => null,
            'url' => null,
            'src' => null,
            'size' => 'widescreen',
        ), $atts));

        $iframeSrc = (!empty($link)) ? $link : null;
        $iframeSrc = (!empty($url) && empty($iframeSrc)) ? $url : $iframeSrc;
        $iframeSrc = (!empty($src) && empty($iframeSrc)) ? $src : $iframeSrc;

        return sprintf(
            '<div class="embedContent %s"><iframe src="%s"></iframe></div>',
            esc_attr($size),
            esc_url($iframeSrc)
        );
    }

/**
 * Checkbox Block Shortcode Function
 *
 * @return string Output from shortcode
 */
    public function checkbox_block_shortcode($atts, $content = null) {
        extract(shortcode_atts(array(
            'styles' => null,
        ), $atts));

        return sprintf(
            '<div class="checkboxBlock %s">%s</div>',
            esc_attr($styles),
            $content
        );
    }

/**
 * Get TinyMCE settings for ACF
 *
 * @return void
 */
    public function formatTinymceFooterACF() {
        $tinyMCE = $this->formatTinymce();
?>
<script type="text/javascript">
acf.add_filter('wysiwyg_tinymce_settings', function( mceInit, id ){

    mceInit.toolbar1 = "<?php echo $tinyMCE['toolbar1']; ?>";
    mceInit.toolbar2 = "<?php echo $tinyMCE['toolbar2']; ?>";
    mceInit.style_formats = <?php echo $tinyMCE['style_formats']; ?>;

	return mceInit;
});
</script>
<?php
    }

/**
 * Set up Advanced Custom Fields
 *
 * @return void
 */
    public function acfSetup() {
        if (function_exists('acf_add_options_page')) {
            acf_add_options_page();
        }

        if (function_exists('acf_add_local_field_group')) {
            acf_add_local_field_group(array(
                'key' => 'group_5a97341a509b7',
                'title' => 'Options',
                'fields' => array(
                    array(
                        'key' => 'field_5a973421ddad7',
                        'label' => 'Phone',
                        'name' => 'phone',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'maxlength' => '',
                    ),
                    array(
                        'key' => 'field_5a999cecfd033',
                        'label' => 'Spanish Link',
                        'name' => 'spanish_link',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'maxlength' => '',
                    ),
                    array(
                        'key' => 'field_5a9993e255d04',
                        'label' => 'Footer Content',
                        'name' => 'footer_content',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'delay' => 0,
                    ),
                    array(
                        'key' => 'field_5a99c047f4ec0',
                        'label' => 'Sidebar Content',
                        'name' => 'sidebar_content',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'delay' => 0,
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'options_page',
                            'operator' => '==',
                            'value' => 'acf-options',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'normal',
                'style' => 'seamless',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => 1,
                'description' => '',
            ));

            acf_add_local_field_group(array(
                'key' => 'group_5a9c9b08b6e4e',
                'title' => 'Page - Bottom',
                'fields' => array(
                    array(
                        'key' => 'field_5a9c9b0d5b551',
                        'label' => 'Custom Sidebar',
                        'name' => 'custom_sidebar',
                        'type' => 'true_false',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'message' => '',
                        'default_value' => 0,
                        'ui' => 1,
                        'ui_on_text' => 'Custom',
                        'ui_off_text' => 'Default',
                    ),
                    array(
                        'key' => 'field_5a9c9b245b552',
                        'label' => 'Custom Sidebar Content',
                        'name' => 'custom_sidebar_content',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => array(
                            array(
                                array(
                                    'field' => 'field_5a9c9b0d5b551',
                                    'operator' => '==',
                                    'value' => '1',
                                ),
                            ),
                        ),
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'delay' => 0,
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'page',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'normal',
                'style' => 'seamless',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => 1,
                'description' => '',
            ));

            acf_add_local_field_group(array(
                'key' => 'group_5a998a7fb2211',
                'title' => 'Page - Front',
                'fields' => array(
                    array(
                        'key' => 'field_5a998a9195e63',
                        'label' => 'Callouts',
                        'name' => 'callouts',
                        'type' => 'repeater',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'collapsed' => 'field_5a998ac195e65',
                        'min' => 2,
                        'max' => 2,
                        'layout' => 'block',
                        'button_label' => 'Add Callout',
                        'sub_fields' => array(
                            array(
                                'key' => 'field_5a998ab395e64',
                                'label' => 'Background Image',
                                'name' => 'background_image',
                                'type' => 'image',
                                'instructions' => '',
                                'required' => 0,
                                'conditional_logic' => 0,
                                'wrapper' => array(
                                    'width' => '',
                                    'class' => '',
                                    'id' => '',
                                ),
                                'return_format' => 'id',
                                'preview_size' => 'full',
                                'library' => 'all',
                                'min_width' => '',
                                'min_height' => '',
                                'min_size' => '',
                                'max_width' => '',
                                'max_height' => '',
                                'max_size' => '',
                                'mime_types' => '',
                            ),
                            array(
                                'key' => 'field_5a998ac195e65',
                                'label' => 'Title',
                                'name' => 'title',
                                'type' => 'text',
                                'instructions' => '',
                                'required' => 0,
                                'conditional_logic' => 0,
                                'wrapper' => array(
                                    'width' => '',
                                    'class' => '',
                                    'id' => '',
                                ),
                                'default_value' => '',
                                'placeholder' => '',
                                'prepend' => '',
                                'append' => '',
                                'maxlength' => '',
                            ),
                            array(
                                'key' => 'field_5a998ac495e66',
                                'label' => 'Subtitle',
                                'name' => 'subtitle',
                                'type' => 'text',
                                'instructions' => '',
                                'required' => 0,
                                'conditional_logic' => 0,
                                'wrapper' => array(
                                    'width' => '',
                                    'class' => '',
                                    'id' => '',
                                ),
                                'default_value' => '',
                                'placeholder' => '',
                                'prepend' => '',
                                'append' => '',
                                'maxlength' => '',
                            ),
                            array(
                                'key' => 'field_5a9c5dab3932c',
                                'label' => 'Subtitle (Italics)',
                                'name' => 'subtitle_italics',
                                'type' => 'text',
                                'instructions' => '',
                                'required' => 0,
                                'conditional_logic' => 0,
                                'wrapper' => array(
                                    'width' => '',
                                    'class' => '',
                                    'id' => '',
                                ),
                                'default_value' => '',
                                'placeholder' => '',
                                'prepend' => '',
                                'append' => '',
                                'maxlength' => '',
                            ),
                            array(
                                'key' => 'field_5a9c9e5d07e6b',
                                'label' => 'Buttons',
                                'name' => 'buttons',
                                'type' => 'repeater',
                                'instructions' => '',
                                'required' => 0,
                                'conditional_logic' => 0,
                                'wrapper' => array(
                                    'width' => '',
                                    'class' => '',
                                    'id' => '',
                                ),
                                'collapsed' => '',
                                'min' => 0,
                                'max' => 0,
                                'layout' => 'row',
                                'button_label' => 'Add Button',
                                'sub_fields' => array(
                                    array(
                                        'key' => 'field_5a9c9e7207e6c',
                                        'label' => 'Button Link',
                                        'name' => 'button_link',
                                        'type' => 'text',
                                        'instructions' => '',
                                        'required' => 0,
                                        'conditional_logic' => 0,
                                        'wrapper' => array(
                                            'width' => '',
                                            'class' => '',
                                            'id' => '',
                                        ),
                                        'default_value' => '',
                                        'placeholder' => '',
                                        'prepend' => '',
                                        'append' => '',
                                        'maxlength' => '',
                                    ),
                                    array(
                                        'key' => 'field_5a9c9e7807e6d',
                                        'label' => 'Button Text',
                                        'name' => 'button_text',
                                        'type' => 'text',
                                        'instructions' => '',
                                        'required' => 0,
                                        'conditional_logic' => 0,
                                        'wrapper' => array(
                                            'width' => '',
                                            'class' => '',
                                            'id' => '',
                                        ),
                                        'default_value' => '',
                                        'placeholder' => '',
                                        'prepend' => '',
                                        'append' => '',
                                        'maxlength' => '',
                                    ),
                                    array(
                                        'key' => 'field_5a9c9e84f903f',
                                        'label' => 'Button Style',
                                        'name' => 'button_style',
                                        'type' => 'select',
                                        'instructions' => '',
                                        'required' => 0,
                                        'conditional_logic' => 0,
                                        'wrapper' => array(
                                            'width' => '',
                                            'class' => '',
                                            'id' => '',
                                        ),
                                        'choices' => array(
                                            'green' => 'Default (Green)',
                                            'whiteOutline' => 'White Outline',
                                        ),
                                        'default_value' => array(
                                            0 => 'green',
                                        ),
                                        'allow_null' => 0,
                                        'multiple' => 0,
                                        'ui' => 1,
                                        'ajax' => 0,
                                        'return_format' => 'value',
                                        'placeholder' => '',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    array(
                        'key' => 'field_5a9c56b5be432',
                        'label' => 'Section 1 Content',
                        'name' => 'section_1_content',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'delay' => 0,
                    ),
                    array(
                        'key' => 'field_5a9c56bfbe433',
                        'label' => 'Section 1 Image',
                        'name' => 'section_1_image',
                        'type' => 'image',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'return_format' => 'id',
                        'preview_size' => 'full',
                        'library' => 'all',
                        'min_width' => '',
                        'min_height' => '',
                        'min_size' => '',
                        'max_width' => '',
                        'max_height' => '',
                        'max_size' => '',
                        'mime_types' => '',
                    ),
                    array(
                        'key' => 'field_5a9c56c5be434',
                        'label' => 'Section 2 Content',
                        'name' => 'section_2_content',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'delay' => 0,
                    ),
                    array(
                        'key' => 'field_5a9c56cc3bfd5',
                        'label' => 'Section 2 Image',
                        'name' => 'section_2_image',
                        'type' => 'image',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'return_format' => 'id',
                        'preview_size' => 'full',
                        'library' => 'all',
                        'min_width' => '',
                        'min_height' => '',
                        'min_size' => '',
                        'max_width' => '',
                        'max_height' => '',
                        'max_size' => '',
                        'mime_types' => '',
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'page_type',
                            'operator' => '==',
                            'value' => 'front_page',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'acf_after_title',
                'style' => 'seamless',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => 1,
                'description' => '',
            ));

            acf_add_local_field_group(array(
                'key' => 'group_5a99b98062524',
                'title' => 'Page - Top',
                'fields' => array(
                    array(
                        'key' => 'field_5a99b99607b2c',
                        'label' => 'Featured Subtitle',
                        'name' => 'featured_subtitle',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'maxlength' => '',
                    ),
                    array(
                        'key' => 'field_5a99b99f07b2d',
                        'label' => 'Featured Button Link',
                        'name' => 'featured_button_link',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'maxlength' => '',
                    ),
                    array(
                        'key' => 'field_5a99b9a407b2e',
                        'label' => 'Featured Button Text',
                        'name' => 'featured_button_text',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'maxlength' => '',
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'page',
                        ),
                        array(
                            'param' => 'page_type',
                            'operator' => '!=',
                            'value' => 'front_page',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'acf_after_title',
                'style' => 'seamless',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => 1,
                'description' => '',
            ));
        }
    }

}

global $MultiFundingUSA2018;

$MultiFundingUSA2018 = new MultiFundingUSA2018();

endif;
