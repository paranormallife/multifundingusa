<?php
/**
 * Part - Footer
 *
 * @file            footer.php
 * @package         MultiFunding USA (2018)
 */

    get_template_part('parts/layout/footer');
?>
