(function($) {
    
    $(function() {
        $('.menuToggle').click(function(e) {
            e.preventDefault();
            $('#navigationMobile').scrollTop(0);
            $('body').toggleClass('pushRight');
        });
        
        $(document).keyup(function(e) {
            $('body').removeClass('pushRight');
        });
    });
} )(jQuery);
