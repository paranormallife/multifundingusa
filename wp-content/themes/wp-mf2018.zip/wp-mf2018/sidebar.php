<?php
/**
 * Part - Sidebar
 *
 * @file            sidebar.php
 * @package         MultiFunding USA (2018)
 */

    get_template_part('parts/layout/sidebar');
?>
