<?php
/**
 * 404
 *
 * @file            404.php
 * @package         MultiFunding USA (2018)
 */

    get_header();
    
    get_template_part('parts/content/none');
        
    get_footer();
?>
