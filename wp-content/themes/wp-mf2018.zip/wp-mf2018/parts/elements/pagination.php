<?php
/**
 * Parts - Elements - Pagination
 *
 * @file            parts/elements/pagination.php
 * @package         MultiFunding USA (2018)
 */
 
    global $paged, $wp_query;

    $maxpage = (empty($maxpage)) ? $wp_query->max_num_pages : $maxpage;
    $nextpage = intval($paged) + 1;

    $firstpage = 1;
    $lastpage = $maxpage;

    if ($paged - 2 <= 1) {
        $firstpage = 1;
        $lastpage = min(5, $maxpage);
    } else if($paged + 2 >= $maxpage) {
        $lastpage = $maxpage;
        $firstpage = max(1, $maxpage - 4);
    } else {
        $firstpage = max(1, $paged - 2);
        $lastpage = min($maxpage, $paged + 2);
    }

    if ($maxpage > 1) :
?>
    <div class="pagination">
<?php
        if (get_previous_posts_link()) :
            echo get_previous_posts_link('&lt; Previous');
            echo '<span class="divider">|</span>';
        endif;
?>
        <span class="numbers">
<?php
        if ($firstpage > 1) :
?>
            <a href="<?php echo get_pagenum_link(1); ?>" class="block"><?php echo __('1'); ?></a>
            <span class="block">...</span>
<?php
        endif;
        for ($i = $firstpage; $i <= $lastpage; $i++) :
            $currpage = ($i == $paged || ($i == 1 && empty($paged))) ? false : true;
            if ($currpage) :
?>
            <a href="<?php echo get_pagenum_link($i); ?>" class="block">
<?php
            else :
?>
            <span class="block current">
<?php
            endif;
            echo $i;
            if ($currpage) :
?>
            </a>
<?php
            else :
?>
            </span>
<?php
            endif;
        endfor;
        if ($lastpage < $maxpage) :
?>
            <span class="block">...</span>
            <a href="<?php echo get_pagenum_link($maxpage); ?>" class="block"><?php echo __($maxpage); ?></a>
<?php
        endif;
?>
        </span>
<?php
        if ($nextpage <= $maxpage) :
            echo '<span class="divider">|</span>';
            echo get_next_posts_link('Next &gt;', $wp_query->max_num_pages);
        endif;
?>
    </div>
<?php
    endif;
?>
