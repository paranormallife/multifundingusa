<?php
/**
 * Parts - Elements - Featured Image
 *
 * @file            parts/elements/featured-image.php
 * @package         MultiFunding USA (2018)
 */
 
    global $post;
 
    $title = null;
    $currentID = null;
    
    if (is_home() || is_archive() || is_search() || is_single()) :
        $postsPageID = get_option('page_for_posts');
        $currentID = $postsPageID;
        
        if (is_category()) :
            $title = sprintf('Category: %s', single_cat_title('', false));
        elseif (is_author()) :
            $title = sprintf(__('Posts By: %s'), get_the_author_meta('display_name'));
        elseif (is_search()) :
            $title = sprintf(__('Search Results for "%s":'), get_search_query());
        elseif (is_archive()) :
            $title = get_the_archive_title();
        elseif (is_home() || is_single()) :
            $title = get_the_title($postsPageID);
        endif;
    else :
        $title = get_the_title();
    endif;

    if (has_post_thumbnail($currentID)) :
        $src = wp_get_attachment_image_src(get_post_thumbnail_id($currentID), 'full', false);
        $src = (isset($src[0])) ? $src[0] : null;
        
        $featuredSubtitle = get_field('featured_subtitle', $currentID);
        $featuredButtonLink = get_field('featured_button_link', $currentID);
        $featuredButtonText = get_field('featured_button_text', $currentID);
?>
    <div class="featuredImage" style="background-image:url('<?php echo esc_url($src); ?>');">
        <div class="image">
            <?php the_post_thumbnail(); ?>
        </div>
        <div class="inner">
            <div class="container">
                <h1><?php echo esc_html($title); ?></h1>
<?php
                if (!empty($featuredSubtitle)) :
?>
                <h3><?php echo esc_html($featuredSubtitle); ?></h3>
<?php
                endif;
                if (!empty($featuredButtonLink) && !empty($featuredButtonText)) :
?>
                <a href="<?php echo esc_url($featuredButtonLink); ?>" class="button lg green">
                    <?php echo esc_html($featuredButtonText); ?>
                </a>
<?php
                endif;
?>
            </div>
        </div>
    </div>
<?php
    endif;
?>
