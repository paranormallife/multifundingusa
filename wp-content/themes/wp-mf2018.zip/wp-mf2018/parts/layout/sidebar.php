<?php
/**
 * Parts - Layout - Sidebar
 *
 * @file            parts/layout/sidebar.php
 * @package         MultiFunding USA (2018)
 */

    $customSidebar = get_field('custom_sidebar');
    
    if (!empty($customSidebar)) :
        $sidebarContent = get_field('custom_sidebar_content', null, false);
    else :
        $sidebarContent = get_field('sidebar_content', 'option', false);
    endif;
?>
    <aside id="sidebar" class="<?php echo (has_post_thumbnail()) ? 'featuredEnabled' : 'feauturedDisabled'; ?>">
        <div class="inner styles">
            <?php echo apply_filters('the_content', $sidebarContent); ?>
        </div>
    </aside>
