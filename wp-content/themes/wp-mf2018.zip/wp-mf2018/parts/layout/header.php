<?php
/**
 * Parts - Layout - Header
 *
 * @file            parts/layout/header.php
 * @package         MultiFunding USA
 * @modified        2019-09-13
 */

$spanishLink = get_field('spanish_link', 'option');
$phone = get_field('phone', 'option');

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php wp_title(''); ?></title>

    <meta name="apple-mobile-web-app-title" content="<?php bloginfo('name'); ?>" />
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" />

    <link type="image/x-icon" rel="icon" href="<?php echo get_bloginfo('template_url'); ?>/favicon.ico" />
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('title'); ?>" href="<?php bloginfo('rss2_url'); ?>" />

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div id="site">
        <header id="header">
            <div class="top">
                <div class="container">
                    <div class="logo multifundingusa">
                        <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>
                    </div>
                    <div class="header-inner">
<?php
                        if (!empty($phone)) :
?>
                        <a class="phone" href="tel:<?php echo esc_attr($phone); ?>"><i class="fa fa-phone"></i> <?php echo esc_attr($phone); ?></a>
<?php
                        endif;
                        if (!empty($spanishLink)) :
?>
                        <a href="<?php echo esc_url($spanishLink); ?>" class="button" target="_blank"><?php echo __('Español'); ?></a>
<?php
                        endif;
?>
                    </div>
                    <a class="badge-nmls" href="https://multifundingusa.com/nmls-certified/">
                        <span>
                            <?php echo __('MultiFunding USA NMLS Certified NMLS License #1683393'); ?>
                        </span>
                    </a>
                </div>
            </div>
            <div class="bottom">
                <div class="container">
                    <div class="tagline">
                        <?php bloginfo('description'); ?>
                    </div>
<?php
                    if (has_nav_menu('main')) :
?>
                    <nav id="navigationMain">
<?php
                        wp_nav_menu(array(
                            'theme_location' => 'main',
                            'container' => false,
                            'fallback_cb' => false,
                        ));
?>
                    </nav>
<?php
                    endif;
?>
                </div>
            </div>
        </header>
