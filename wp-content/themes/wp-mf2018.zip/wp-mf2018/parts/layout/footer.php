<?php
/**
 * Parts - Layout - Footer
 *
 * @file            parts/layout/footer.php
 * @package         MultiFunding USA
 * @modified        2019-09-13
 */

$spanishLink = get_field('spanish_link', 'option');
$phone = get_field('phone', 'option');
$footerContent = get_field('footer_content', 'option', false);

?>
        <footer id="footer">
            <div class="inner">
                <?php echo apply_filters('the_content', $footerContent); ?>
            </div>
            <div class="createdby">
                <p style="margin-bottom:8px;margin-bottom:0.5rem;"><strong><?php echo __('PROUD SUPPORTER OF'); ?></strong></p>
                <p style="margin-bottom:8px;margin-bottom:0.5rem;"><a href="https://www.jdrf.org/" target="_blank"><img src="<?php echo get_bloginfo('template_url'); ?>/assets/images/logo-jdrf.png" alt="<?php echo __('JDRF'); ?>" width="175" height="55" /></a></p>
            </div>
        </footer>
    </div>
    <a id="menuToggle" class="menuToggle" href="#">
        <i class="fa fa-bars"></i>
        <i class="fa fa-close"></i>
    </a>
    <div id="navigationMobile">
<?php
        if (!empty($phone)) :
?>
        <div class="block"><a class="phone" href="tel:<?php echo esc_attr($phone); ?>"><i class="fa fa-phone"></i> <?php echo esc_attr($phone); ?></a></div>
<?php
        endif;
        if (!empty($spanishLink)) :
?>
        <div class="block"><a href="<?php echo esc_url($spanishLink); ?>" class="button" target="_blank"><?php echo __('Español'); ?></a></div>
<?php
        endif;
?>
        <div class="block">
            <a class="badge-nmls" href="https://multifundingusa.com/nmls-certified/">
                <span>
                    <?php echo __('MultiFunding USA NMLS Certified NMLS License #1683393'); ?>
                </span>
            </a>
        </div>
        <nav class="navMenu">
<?php
            if (has_nav_menu('main')) :
                wp_nav_menu(array(
                    'theme_location' => 'main',
                    'container' => false,
                    'fallback_cb' => false,
                ));
            endif;
?>
        </nav>
<?php

?>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
