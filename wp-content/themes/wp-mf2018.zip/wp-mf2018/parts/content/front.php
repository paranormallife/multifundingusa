<?php
/**
 * Parts - Content - Front
 *
 * @file            parts/content/front.php
 * @package         MultiFunding USA (2018)
 */

    while (have_posts()) :
        the_post();
        
        $callouts = get_field('callouts');
        $section1Content = get_field('section_1_content', null, false);
        $section1Image = get_field('section_1_image');
        $section2Content = get_field('section_2_content', null, false);
        $section2Image = get_field('section_2_image');
?>
    <div id="templateFront" class="content front">
<?php
    if (!empty($callouts)) :
?>
        <div class="callouts">
<?php
        foreach ($callouts as $callout) :
            $src = wp_get_attachment_image_src($callout['background_image'], 'full', false);
            $src = (isset($src[0])) ? $src[0] : null;
?>
        <div class="callout" style="background-image:url('<?php echo esc_url($src); ?>');">
            <div class="image">
                <?php echo wp_get_attachment_image($callout['background_image']); ?>
            </div>
            <div class="mask">&nbsp;</div>
            <div class="inner">
                <h3><?php echo esc_html($callout['title']); ?></h3>
                <h6>
                    <?php echo esc_html($callout['subtitle']); ?><br />
                    <em><?php echo esc_html($callout['subtitle_italics']); ?></em>
                </h6>
<?php
                if (!empty($callout['buttons']) && is_array($callout['buttons'])) :
                    foreach ($callout['buttons'] as $button) :
?>
                <a href="<?php echo esc_url($button['button_link']); ?>" class="button lg <?php echo $button['button_style']; ?>">
                    <?php echo esc_html($button['button_text']); ?>
                </a>
<?php
                    endforeach;
                endif;
?>
            </div>
        </div>
<?php
        endforeach;
?>
        </div>
<?php
    endif;
?>
        <div class="section section-1">
            <div class="container styles">
                <div class="row break-lg">
                    <div class="column six valign-middle">
                        <?php echo apply_filters('the_content', $section1Content); ?>
                    </div>
                    <div class="column six valign-middle break-hide-lg">
                        <?php echo wp_get_attachment_image($section1Image, 'full'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="section section-2">
            <div class="container styles dark">
                <div class="row break-lg">
                    <div class="column six valign-middle break-hide-lg">
                        <?php echo wp_get_attachment_image($section2Image, 'full', false, array('class' => 'aligncenter margin-none')); ?>
                    </div>
                    <div class="column six valign-middle padding">
                        <?php echo apply_filters('the_content', $section2Content); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="section section-3">
            <div class="container styles">
                <?php the_content(); ?>
            </div>
        </div>
    </div>
<?php
    endwhile;
?>
