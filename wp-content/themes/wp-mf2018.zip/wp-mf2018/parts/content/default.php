<?php
/**
 * Parts - Content - Default
 *
 * @file            parts/content/default.php
 * @package         MultiFunding USA (2018)
 */

    while (have_posts()) :
        the_post();
?>
    <div id="templateDefault" class="content default">
<?php
        get_template_part('parts/elements/featured-image');
?>
        <div class="container">
            <div id="main">
                <div id="body" class="styles">
<?php
                    if (is_single()) :
?>
                    <h1><?php the_title(); ?></h1>
<?php
                    endif
?>
                    <?php the_content(); ?>
                </div>
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
<?php
    endwhile;
?>
