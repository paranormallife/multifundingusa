<?php
/**
 * Parts - Content - Archive
 *
 * @file            parts/content/archive.php
 * @package         MultiFunding USA (2018)
 */

?>
    <div id="templateDefault" class="content archive">
<?php
        get_template_part('parts/elements/featured-image');
?>
        <div class="container">
            <div id="main">
                <div id="body" class="styles">
<?php
                while (have_posts()) :
                    the_post();
?>  
                    <div class="excerpt">
                        <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                        <?php the_excerpt(); ?>
                        <p><a href="<?php the_permalink(); ?>" class="textUpper"><?php echo __('Read More'); ?></a></p>
                        <hr />
                    </div>
<?php   
                endwhile;
                get_template_part('parts/elements/pagination');
?>
                </div>
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
