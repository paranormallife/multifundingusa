<?php
/**
 * Parts - Content - None
 *
 * @file            parts/content/none.php
 * @package         MultiFunding USA (2018)
 */

?>
    <div id="templateNone" class="content default">
        <div class="container">
            <div id="main">
                <div id="body" class="styles">
                    <h1><?php echo __('Not Found'); ?></h1>
                    <p><?php echo __('Sorry, the page you were looking for could not be found.'); ?></p>
                </div>
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
