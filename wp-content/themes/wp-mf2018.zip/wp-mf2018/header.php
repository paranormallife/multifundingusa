<?php
/**
 * Part - Header
 *
 * @file            header.php
 * @package         MultiFunding USA (2018)
 */

    get_template_part('parts/layout/header');
?>
