<?php
/**
 * Index
 *
 * @file            index.php
 * @package         MultiFunding USA (2018)
 */

    get_header();
    
    if (have_posts()) :
        if (is_front_page()) :
            get_template_part('parts/content/front');
        elseif (is_home() || is_archive() || is_search()) :
            get_template_part('parts/content/archive');
        else :
            get_template_part('parts/content/default');
        endif;
    else :
        get_template_part('parts/content/none');
    endif;

    get_footer();
?>
